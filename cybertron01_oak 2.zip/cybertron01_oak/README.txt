make sure mongoDB is running!

run application:
deno run -Ar index.js

tunnel from local machine:
ngrok http http://localhost:8080
