import { Application } from 'https://deno.land/x/oak@v12.0.0/mod.ts'
import { oakCors } from "https://deno.land/x/cors/mod.ts";
import { router } from './routes/routes.js'
import { validate } from './utils/validate.js'

const app = new Application()
app.addEventListener("error", (event) => {
    console.log(event.error);
});

// app.use(
//   oakCors({
//     origin: true
//   }),
// );

app.use(validate)
app.use(router.routes())
app.use(router.allowedMethods())


console.log(`Listening on port 8080...`)
await app.listen({port : 8080})