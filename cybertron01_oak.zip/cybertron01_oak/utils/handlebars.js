import { Handlebars } from 'https://deno.land/x/handlebars/mod.ts'

export const handle = new Handlebars();